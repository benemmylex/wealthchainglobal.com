<?php

header('Location:' .$_SERVER['HTTP_REFERER']);

?>