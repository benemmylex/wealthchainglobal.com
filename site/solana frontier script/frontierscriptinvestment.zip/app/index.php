<?php
    header("Location: ../");
?>